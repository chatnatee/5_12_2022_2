from typing import List
def read_file_by_line(filename: str) -> List[str]:
    out = []
    with open(filename, 'r') as file:
        for line in file:
            out.append(line.replace('\n', ''))

    return out

def read_file_and_split(filename: str, divider: str) -> List[List[str]]:
    out = []
    with open(filename, 'r') as file:
        for line in file:
            out.append(line.replace('\n', '').split(divider))
    return out

# for day 3 :P : divide string in half
'''
a = 'vnduoivcoHBUOvbhi;p'
b = 'BJbuoouGBUBIuUOboui'
print(set(a).intersection(b))
'''



