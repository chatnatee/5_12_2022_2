from utils import read_file_by_line, read_file_and_split
from typing import List

def parse_command(command: str) -> (int, int, int):
    out = command.split(' ')
    return int(out[1]), int(out[3]) - 1, int(out[5]) - 1

def get_trops(state: List[List[str]]) -> str:
    out = ''
    for pile in state:
        out += pile[0]
    return out

def part1(state: List[List[str]], commands: List[str]) -> str:
    for command in commands:
        count, start, end = parse_command(command)
        for i in range(0, count):
            temp = state[start].pop(0)
            state[end].insert(0, temp)
    return get_trops(state)

def main():
    commands = read_file_by_line('input-instruction.txt')
    start_state = read_file_and_split('input-state.txt', ',')
    print(start_state)


if __name__ == "__main__":
    main()





